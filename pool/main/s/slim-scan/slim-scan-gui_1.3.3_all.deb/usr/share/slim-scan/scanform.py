"""Toolkit-independent logic of the Slim Scan app.

Everything here is plain Python so it can be tested without GTK: which
choices a scanner allows, turning form values into scan arguments and the
shared config file, and user-facing progress texts.
"""

import os
import shutil
import subprocess
import sys
import unicodedata
from types import SimpleNamespace

import i18n
import slim_scan

TRANSLATION = i18n.translation()
_ = TRANSLATION.gettext
ngettext = TRANSLATION.ngettext
pgettext = TRANSLATION.pgettext  # for a word used in two meanings

APP_ID = "io.github.linuxrrze.SlimScan"
APP_NAME = "Slim Scan"
VERSION = "1.3.3"

# (value, label) pairs in display order.
SOURCES = [("duplex", _("Both sides")), ("adf", _("One side"))]
MODES = [("color", _("Color")), ("gray", _("Grayscale")), ("bw", _("Black & white"))]
PAPERS = [("auto", _("Automatic")), ("a4", "A4"), ("a5", "A5"), ("letter", "Letter"),
          ("legal", "Legal")]
BACKENDS = [("wsd", _("Network (WSD)")), ("sane", "SANE")]
# Paper size "auto": which of the sheet's edges are cut (slim_scan.CROP_CHOICES).
CROPS = [("sides", _("Left and right")), ("all", _("All sides"))]
OCR_ENGINES = [("auto", _("Automatic")), ("tesseract", "Tesseract"), ("ocrmypdf", "OCRmyPDF")]
DEFAULT_RESOLUTIONS = [100, 150, 200, 300, 600]

# [gui] section of the shared config file.
GUI_DEFAULTS = {"open_after_scan": False, "notify": True, "width": 480, "height": 720,
                "tray": False, "last_scanner": ""}


def display_path(path):
    """Show folders in the home folder as '~/Documents/Scans'."""
    home = os.path.expanduser("~")
    if path == home or path.startswith(home.rstrip("/") + "/"):
        return "~" + path[len(home.rstrip("/")):]
    return path


def documents_dir():
    """The user's Documents folder (XDG), falling back to the home folder."""
    try:
        path = subprocess.run(["xdg-user-dir", "DOCUMENTS"], capture_output=True, text=True,
                              timeout=2).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        path = ""
    home = os.path.expanduser("~")
    if path and path != home and os.path.isdir(path):
        return path
    fallback = os.path.join(home, "Documents")
    return fallback if os.path.isdir(fallback) else home


def remembered_outdir(folder, outdir):
    """The folder setting to store after saving a scan in folder, or None if
    it is already the default. An empty setting keeps following Documents."""
    if folder == (outdir or documents_dir()):
        return None
    return folder


def load_gui_config():
    raw = slim_scan.load_config_section("gui")
    values = dict(GUI_DEFAULTS)
    for key, default in GUI_DEFAULTS.items():
        if key not in raw:
            continue
        text = raw[key].strip().lower()
        if isinstance(default, bool):
            values[key] = text in ("true", "yes", "1", "on")
        elif isinstance(default, str):
            values[key] = raw[key].strip()
        elif text.isdigit():
            values[key] = int(text)
    return values


# Display names for common Tesseract language codes.
LANGUAGE_NAMES = {
    "ara": _("Arabic"), "bul": _("Bulgarian"), "cat": _("Catalan"), "ces": _("Czech"),
    "chi_sim": _("Chinese (simplified)"), "chi_tra": _("Chinese (traditional)"),
    "dan": _("Danish"), "deu": _("German"), "ell": _("Greek"), "eng": _("English"),
    "est": _("Estonian"), "fin": _("Finnish"), "fra": _("French"), "heb": _("Hebrew"),
    "hrv": _("Croatian"), "hun": _("Hungarian"), "ita": _("Italian"), "jpn": _("Japanese"),
    "kor": _("Korean"), "lav": _("Latvian"), "lit": _("Lithuanian"), "nld": _("Dutch"),
    "nor": _("Norwegian"), "pol": _("Polish"), "por": _("Portuguese"), "ron": _("Romanian"),
    "rus": _("Russian"), "slk": _("Slovak"), "slv": _("Slovenian"), "spa": _("Spanish"),
    "srp": _("Serbian"), "swe": _("Swedish"), "tur": _("Turkish"), "ukr": _("Ukrainian"),
}


def language_label(code):
    name = LANGUAGE_NAMES.get(code)
    return f"{name} ({code})" if name else code


class OcrStatus:
    """Which OCR engines and languages are installed (checked once at startup)."""

    INSTALL_HINT = _("Install Tesseract or OCRmyPDF to enable text recognition, "
                     "e.g. “sudo apt install tesseract-ocr”.")

    OSD_HINT = _("Needs Tesseract with orientation data, e.g. "
                 "“sudo apt install tesseract-ocr-osd”.")

    def __init__(self, engines, languages, osd=False):
        self.engines = engines            # installed engine names, preferred first
        self.languages = languages        # installed Tesseract languages
        self.default_lang = slim_scan.default_ocr_languages(languages)
        self.osd = osd                    # Tesseract can detect page orientation

    @classmethod
    def detect(cls):
        return cls([name for name, _path in slim_scan.ocr_engines()],
                   slim_scan.tesseract_languages(), slim_scan.tesseract_osd_available())

    @property
    def available(self):
        return bool(self.engines)

    def engine_options(self):
        """Engine choices for the preferences: Automatic plus the installed ones."""
        return [(v, label) for v, label in OCR_ENGINES if v == "auto" or v in self.engines]

    def language_choices(self, configured):
        """(code, label, selected, installed) for the language list in the preferences.

        Ordered like the automatic choice (system language and English first);
        `configured` is the saved 'deu+eng' value ('' = automatic). Configured
        languages that are not installed are listed too, so they can be removed.
        """
        selected = [code for code in (configured or "").split("+") if code]
        order = self.default_lang.split("+") + self.languages + selected
        return [(code, language_label(code), code in selected, code in self.languages)
                for code in dict.fromkeys(order) if code]

    @staticmethod
    def join_languages(choices, selected_codes):
        """The ocr_lang value for the selected codes, in list order ('' if none)."""
        return "+".join(code for code, *_rest in choices if code in selected_codes)

    def describe(self, engine, lang):
        """Subtitle of the OCR switch, e.g. 'Tesseract · deu+eng'."""
        if not self.available:
            return self.INSTALL_HINT
        name = engine if engine in self.engines else self.engines[0]
        return f"{dict(OCR_ENGINES)[name]} · {lang or self.default_lang}"


class Choices:
    """What the form may offer, narrowed down by the scanner's capabilities."""

    def __init__(self, sources, modes, resolutions, lossless, lossless_hint, exposure,
                 hardware=()):
        self.sources = sources            # [(value, label)]
        self.modes = modes                # [(value, label)]
        self.resolutions = resolutions    # [int]
        self.lossless = lossless          # "free", "on" (forced) or "off" (unavailable)
        self.lossless_hint = lossless_hint
        self.exposure = exposure          # brightness/contrast adjustable
        self.hardware = tuple(hardware)   # the scanner's own corrections: "crop", "skew" (SANE)

    @classmethod
    def unknown(cls):
        """Before the scanner answered: offer everything."""
        return cls(list(SOURCES), list(MODES), list(DEFAULT_RESOLUTIONS), "free", "", True)

    @classmethod
    def from_capabilities(cls, caps):
        formats = caps.get("formats") or []
        has_tiff = not formats or slim_scan.TIFF_FORMAT in formats
        has_jpeg = not formats or any(f in formats for f in slim_scan.JPEG_FORMATS)
        colors = caps.get("colors") or []

        def offered(mode):
            return not colors or slim_scan.COLOR_ENTRIES[mode] in colors

        modes = [(v, label) for v, label in MODES
                 if offered(v) and (has_tiff if v == "bw" else (has_jpeg or has_tiff))]
        sources = [(v, label) for v, label in SOURCES if v != "duplex" or caps.get("duplex")]
        if not has_tiff:
            lossless, hint = "off", _("Not offered by this scanner")
        elif not has_jpeg:
            lossless, hint = "on", _("This scanner only sends uncompressed images")
        else:
            lossless, hint = "free", ""
        ds = caps.get("device_settings") or {}
        exposure = ds.get("brightness") is not False or ds.get("contrast") is not False
        sane = caps.get("sane") or {}
        hardware = [name for name in ("crop", "skew") if sane.get(name)]
        return cls(sources, modes, caps.get("resolutions") or list(DEFAULT_RESOLUTIONS),
                   lossless, hint, exposure, hardware)

    def pick(self, options, value):
        """`value` if offered, else the first offered value."""
        values = [v for v, _label in options]
        return value if value in values else (values[0] if values else value)

    def pick_resolution(self, dpi):
        """`dpi` if offered, else the closest offered resolution."""
        if dpi in self.resolutions or not self.resolutions:
            return dpi
        return min(self.resolutions, key=lambda r: (abs(r - dpi), r))

    def lossless_state(self, mode, wanted):
        """(checked, sensitive, hint) for the lossless switch."""
        if mode == "bw":
            return True, False, _("Black & white is always lossless")
        if self.lossless == "off":
            return False, False, self.lossless_hint
        if self.lossless == "on":
            return True, False, self.lossless_hint
        return wanted, True, _("Much larger files; no JPEG compression")


def settings_summary(values, review=False):
    """One line for the main window, e.g. 'Both sides · Color · 300 dpi · A4'."""
    parts = [dict(SOURCES).get(values["source"], values["source"]),
             dict(MODES).get(values["mode"], values["mode"]),
             f"{values['resolution']} dpi",
             dict(PAPERS).get(values["paper"], values["paper"])]
    if values["paper"] == "auto" and values.get("crop") == "all":
        parts.append(_("cut on all sides"))
    if values.get("lossless") and values["mode"] != "bw":  # b/w is always lossless
        parts.append(_("lossless"))
    if values.get("brightness") is not None:
        parts.append(_("brightness {n}").format(n=values["brightness"]))
    if values.get("contrast") is not None:
        parts.append(_("contrast {n}").format(n=values["contrast"]))
    if values.get("ocr"):
        parts.append(_("OCR"))
    if values.get("skip_blank"):
        parts.append(_("remove blank pages"))
    if values.get("deskew"):
        parts.append(_("straighten"))
    if values.get("auto_rotate"):
        parts.append(_("turn upright"))
    if review:
        parts.append(_("review pages"))
    return " · ".join(parts)


# --- Scanner profiles ([scanner NAME] sections) --------------------------------

SCANNER_KEYS = [key for key in slim_scan.CONFIG_DEFAULTS if key != "scanner"]


def full_profile(shared, entries):
    """All settings of a scanner: its own values, the rest from [scan].

    The connection, address, SANE device and model filter are never
    inherited: they identify the scanner.
    """
    profile = {key: entries.get(key, shared.get(key, slim_scan.CONFIG_DEFAULTS[key]))
               for key in SCANNER_KEYS}
    for key in IDENTITY_KEYS:
        profile[key] = entries.get(key, slim_scan.CONFIG_DEFAULTS[key])
    return profile


IDENTITY_KEYS = ("backend", "host", "device", "model")


def device_entries(device):
    """The config entries that identify a found scanner."""
    if device.get("backend") == "sane":
        return {"backend": "sane", "device": device["name"]}
    return {"host": slim_scan.device_address(device)}


def scanner_key(entries):
    """What identifies a scanner in profiles or found devices: ("wsd", host)
    or ("sane", device name)."""
    if entries.get("backend") == "sane":
        return "sane", entries.get("device") or entries.get("name") or ""
    return "wsd", entries.get("host") or ""


def find_all_scanners():
    """The scanners on the network (WSD) and the ones SANE finds (if
    installed); raises the first error if there are none."""
    found, errors = [], []
    searches = [lambda: slim_scan.discover(None)]
    if slim_scan.shutil.which("scanimage"):
        searches.append(slim_scan.sane_devices)
    for search in searches:
        try:
            found += search()
        except slim_scan.ScanError as e:
            errors.append(e)
    if not found and errors:
        raise errors[0]
    return found


def scanner_subtitle(entries):
    """'192.168.2.13', 'Found automatically', 'SANE · epsonds:net:…' or with model filter."""
    if entries.get("backend") == "sane":
        parts = ["SANE", entries.get("device") or _("Found automatically")]
    else:
        parts = [entries.get("host") or _("Found automatically")]
    if entries.get("model"):
        parts.append(_("model “{model}”").format(model=entries["model"]))
    return " · ".join(parts)


def unique_scanner_name(base, existing):
    """'Office', or 'Office 2', 'Office 3', ... if taken."""
    base = " ".join((base or _("Scanner")).replace("[", "(").replace("]", ")").split())[:60]
    if base not in existing:
        return base
    n = 2
    while f"{base} {n}" in existing:
        n += 1
    return f"{base} {n}"


def scanner_from_device(device, existing, shared):
    """(name, settings) for a scanner found on the network; settings start
    as a copy of the shared defaults."""
    name = unique_scanner_name(device_name(device), existing)
    return name, full_profile(shared, device_entries(device))


def migrate_scanners(shared, scanners, device=None):
    """Scanners for the preferences, each with all its settings.

    Without configured scanners, the [scan] settings (older versions, or just
    the connected scanner) become the first scanner, named after the device
    if one is connected, e.g. 'EPSON ES-580W'.

    Returns (scanners, default_name, migrated).
    """
    scanners = {name: full_profile(shared, entries) for name, entries in scanners.items()}
    if not scanners and (shared.get("host") or shared.get("model") or device
                         or shared.get("backend") == "sane"):
        entries = {k: shared[k] for k in IDENTITY_KEYS if shared.get(k)
                   and shared[k] != slim_scan.CONFIG_DEFAULTS[k]}
        if device and not entries:
            entries = device_entries(device)
        name = unique_scanner_name(
            (device_name(device) if device else "") or shared.get("model") or _("Scanner"),
            scanners)
        return {name: full_profile(shared, entries)}, name, True
    default = slim_scan.default_scanner_name(shared, scanners)
    return scanners, default if default in scanners else "", False


def needs_reconnect(old, new, connected):
    """After saving preferences: look for the scanner again if its connection,
    address, device or model filter changed, or if no scanner is connected."""
    changed = any(new.get(key) != old.get(key) for key in IDENTITY_KEYS)
    return changed or not connected


def scan_args(values):
    """Form values (as stored in the config) -> arguments for slim_scan.scan_to_file."""
    return SimpleNamespace(
        backend=values.get("backend") or "wsd",
        host=values.get("host") or None,
        device=values.get("device") or None,
        model=values.get("model") or None,
        hardware_corrections=bool(values.get("hardware_corrections", True)),
        sane_options=values.get("sane_options") or "",
        source=values["source"],
        mode=values["mode"],
        resolution=int(values["resolution"]),
        paper=values["paper"],
        lossless=bool(values["lossless"]),
        brightness=values.get("brightness"),
        contrast=values.get("contrast"),
        ocr=bool(values.get("ocr")),
        ocr_engine=values.get("ocr_engine") or "auto",
        ocr_lang=values.get("ocr_lang") or None,
        skip_blank=bool(values.get("skip_blank")),
        deskew=bool(values.get("deskew")),
        crop=values.get("crop") or "sides",
        auto_rotate=bool(values.get("auto_rotate")),
    )


# Icons and tooltips of the corrections shown on a page preview.
CORRECTION_ICONS = {"crop": "slim-scan-crop-symbolic", "skew": "slim-scan-straighten-symbolic",
                    "rotate": "slim-scan-upright-symbolic", "manual": "slim-scan-adjust-symbolic"}
TURN_ICONS = {-90: "slim-scan-turn-left-symbolic", 90: "slim-scan-turn-right-symbolic"}


def correction_tooltip(name, info, dpi, applied):
    """Tooltip of a page's correction icon, e.g. 'Straightened by 3.4°'."""
    if name == "crop":
        width, height = slim_scan.crop_size(info)
        text = _("Cut to the sheet: {w} × {h} mm").format(
            w=round(width / dpi * 25.4), h=round(height / dpi * 25.4))
    elif name == "manual":
        width, height = slim_scan.crop_size(info)
        text = _("Adjusted by hand: {w} × {h} mm, straightened by {angle}°").format(
            w=round(width / dpi * 25.4), h=round(height / dpi * 25.4),
            angle=f"{info['manual'][4]:.1f}")
    elif name == "skew":
        text = _("Straightened by {angle}°").format(angle=f"{abs(info['skew']):.1f}")
    else:
        text = _("Turned upright by {angle}°").format(angle=info["rotate"])
    if not applied:
        text = _("{correction} (off)").format(correction=text)
    return text


def output_path(folder, name):
    """Absolute, non-existing PDF path for the entered file name (None if empty)."""
    name = (name or "").strip()
    if not name or name in (".pdf", ".PDF"):
        return None
    clean = slim_scan.render_filename(name)
    return slim_scan.unique_path(os.path.join(os.path.expanduser(folder), clean))


def progress_text(event, pages, total=0):
    if event == "connecting":
        return _("Connecting to the scanner…")
    if event == "scanning":
        return _("Scanning…")
    if event == "page":
        return ngettext("Scanned {n} page", "Scanned {n} pages", pages).format(n=pages)
    if event == "saving":
        return _("Saving PDF…")
    if event == "ocr":
        return _("Recognizing text…")
    if event == "ocr_page":  # pages = recognized so far; the next one is in progress
        return _("Recognizing text: page {n} of {total}").format(n=min(pages + 1, total),
                                                                 total=total)
    if event == "review":
        return _("Untick the pages you don’t want, then click Save. Scan adds more pages. "
                 "You can still change the file name and folder.")
    return ""


def saved_text(pages, name, complete=True, blank=0):
    """The message after saving a scan; blank = blank pages removed."""
    if not complete:
        return ngettext("Scan stopped early; saved {pages} page as “{name}”",
                        "Scan stopped early; saved {pages} pages as “{name}”",
                        pages).format(pages=pages, name=name)
    saved = ngettext("Saved {pages} page as “{name}”", "Saved {pages} pages as “{name}”",
                     pages).format(pages=pages, name=name)
    return with_blank(saved, blank)


def added_text(pages, name, complete=True, blank=0):
    """The message after adding pages to a saved document."""
    if not complete:
        return ngettext("Scan stopped early; added {pages} page to “{name}”",
                        "Scan stopped early; added {pages} pages to “{name}”",
                        pages).format(pages=pages, name=name)
    added = ngettext("Added {pages} page to “{name}”", "Added {pages} pages to “{name}”",
                     pages).format(pages=pages, name=name)
    return with_blank(added, blank)


def with_blank(saved, blank):
    """The message with the blank pages removed, if any."""
    if not blank:
        return saved
    removed = ngettext("removed {blank} blank page", "removed {blank} blank pages",
                       blank).format(blank=blank)
    return _("{saved}, {removed}").format(saved=saved, removed=removed)


def pages_summary(scanned, kept=None):
    """Header of the page preview, e.g. '4 pages' or '3 of 4 pages kept'."""
    if kept is None or kept == scanned:
        return ngettext("{n} page", "{n} pages", scanned).format(n=scanned)
    return ngettext("{kept} of {n} page kept", "{kept} of {n} pages kept",
                            scanned).format(kept=kept, n=scanned)


# --- Status bar menu and autostart ---------------------------------------------

TRAY_MENU = [  # (id, label, action); id 0 is the menu root
    (1, _("Open Slim Scan"), "open"),
    (2, _("Scan"), "scan"),
    (3, None, None),  # separator
    (4, _("Quit"), "quit"),
]


def tray_menu_layout(enabled):
    """dbusmenu layout as plain Python: (0, root props, [(id, props, [])...]).

    `enabled` maps actions to True/False (e.g. "scan" while scanning).
    """
    children: list[tuple] = []
    for item_id, label, action in TRAY_MENU:
        props: dict[str, object]
        if label is None:
            props = {"type": "separator"}
        else:
            props = {"label": label, "enabled": enabled.get(action, True), "visible": True}
        children.append((item_id, props, []))
    return (0, {"children-display": "submenu"}, children)


def tray_action(item_id):
    return next((action for i, _label, action in TRAY_MENU if i == item_id), None)


def autostart_path():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "autostart", f"{APP_ID}.desktop")


def launch_command():
    """How to start the app: the installed launcher, else python + this file."""
    launcher = shutil.which("slim-scan-gui")
    if launcher:
        return [launcher]
    return [sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                         "slim_scan_gui.py")]


def desktop_exec(args):
    """A command line as an Exec= value (Desktop Entry Specification).

    Arguments with special characters are quoted, with ", `, $ and \\
    escaped inside the quotes; % is doubled (field codes); then backslashes
    are escaped once more for the key-file string. Control characters are
    rejected: a line break would add keys to the file.
    """
    def quote(arg):
        if any(unicodedata.category(c)[0] == "C" for c in arg):
            raise ValueError(f"control character in {arg!r}")
        arg = arg.replace("%", "%%")
        if any(c in arg for c in ' \t\n"\'\\><~|&;$*?#()`='):
            arg = '"' + "".join("\\" + c if c in '"`$\\' else c for c in arg) + '"'
        return arg.replace("\\", "\\\\")
    return " ".join(quote(a) for a in args)


def autostart_entry(command):
    return "\n".join([
        "[Desktop Entry]",
        "Type=Application",
        f"Name={APP_NAME}",
        "Comment=" + _("Slim Scan in the status bar"),
        f"Exec={desktop_exec(command + ['--background'])}",
        f"Icon={APP_ID}",
        "Terminal=false",
        "NoDisplay=true",
        "X-GNOME-Autostart-enabled=true",
        "X-KDE-autostart-after=panel",
        "",
    ])


def autostart_enabled():
    return os.path.exists(autostart_path())


def set_autostart(enabled, command=None):
    path = autostart_path()
    if not enabled:
        if os.path.exists(path):
            os.remove(path)
        return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(autostart_entry(command or launch_command()))


def device_name(device):
    """'EPSON ES-580W': what the scanner calls itself."""
    return f"{device.get('manufacturer') or ''} {device.get('model') or ''}".strip()


def device_label(device):
    """'EPSON ES-580W · 192.168.2.13' (or the SANE device name)."""
    return f"{device_name(device)} · {slim_scan.device_address(device)}"


def scanner_configured(config):
    return bool(config.get("scanner") or config.get("host")
                or (config.get("backend") == "sane" and config.get("device")))


def scanner_problem(error, config):
    """What the main window shows when looking for the scanner failed.

    Tells apart "no scanner set up" (and none found automatically), "the set
    up scanner does not answer" and other errors. Returns a SimpleNamespace:
    status (window subtitle), title and detail (scanner row), banner,
    button and action (banner button), can_scan, retry (look again later).
    """
    sane = config.get("backend") == "sane"
    name = config.get("scanner") or config.get("device" if sane else "host") or ""
    host = config.get("host") or ""
    preferences = "app.preferences"
    if not scanner_configured(config):
        if isinstance(error, slim_scan.ScannerChoiceNeeded):
            return SimpleNamespace(
                status=_("Choose a scanner"), title=_("Several scanners found"),
                detail=str(error),
                banner=_("Several scanners are on the network. Choose yours in the preferences."),
                button=_("Choose Scanner"), action=preferences, can_scan=False, retry=False)
        if isinstance(error, slim_scan.ScannerNotFound):
            return SimpleNamespace(
                status=_("No scanner set up"), title=_("No scanner set up"),
                detail=_("SANE finds no scanner") if sane
                else _("None found automatically on the network"),
                banner=_("No scanner is set up, and none was found on the network. "
                         "Add your scanner in the preferences."),
                button=_("Add Scanner"), action=preferences, can_scan=True, retry=True)
    elif isinstance(error, slim_scan.ScannerNotFound):
        if sane:
            where = (_("Not available through SANE as {device}").format(device=config["device"])
                     if config.get("device") else _("SANE finds no scanner"))
        else:
            where = (_("Not reachable at {host}").format(host=host) if host
                     else _("Not found on the network"))
        return SimpleNamespace(
            status=_("Scanner not reachable"), title=name,
            detail=_("{where} · trying again").format(where=where),
            banner=_("“{name}” is not reachable. Check that it is switched on and "
                     "connected; it is looked for again automatically.").format(name=name),
            button=_("Retry"), action="win.reconnect", can_scan=True, retry=True)
    elif isinstance(error, slim_scan.ScannerChoiceNeeded):
        return SimpleNamespace(
            status=_("Choose a scanner"), title=name, detail=str(error),
            banner=_("Several scanners match “{name}”. Set its address in the "
                     "preferences.").format(name=name),
            button=_("Preferences"), action=preferences, can_scan=False, retry=False)
    return SimpleNamespace(
        status=_("Scanner error"), title=name or _("Scanner"), detail=str(error),
        banner=(_("“{name}” could not be used (see below). Check its settings in the "
                  "preferences.").format(name=name) if name
                else _("The scanner could not be used (see below).")),
        button=_("Preferences"), action=preferences, can_scan=True, retry=True)


# WS-Scan ScannerState values.
SCANNER_STATES = {"Idle": _("Idle"), "Processing": _("Busy"), "Stopped": _("Stopped")}


def describe_scanner(device, caps, name=""):
    """(title, subtitle) for the main window's scanner row.

    The title is the configured scanner name (as in the preferences), else the
    device name; the subtitle adds the device (if named differently), address,
    state and conditions.
    """
    title = name or device_name(device)
    parts = [device_name(device)] if name and name != device_name(device) else []
    parts.append(slim_scan.device_address(device))
    state = caps.get("state") or "?"
    parts.append(SCANNER_STATES.get(state, state))
    parts += caps.get("conditions") or []
    return title, " · ".join(parts)
